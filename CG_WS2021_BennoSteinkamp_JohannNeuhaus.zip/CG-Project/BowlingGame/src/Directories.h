#pragma once

#define RESOURCE_DIR "res"

#define SHADER_DIR RESOURCE_DIR"/shader"

#define MODEL_DIR RESOURCE_DIR"/model"
#pragma once
#include "GameObject.h"

class Background: public GameObject
{
public:
	Background();
};


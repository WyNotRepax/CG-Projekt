Projektteilnehmer: Benno Steinkamp, Johann Neuhaus

Visual Studio 2019 Solution Directory: ./CG_Project
Visual Studio 2019 Project Directory: ./CG_Project/BowlingGame
Blender Ressourcen(Selbst Erstellt): ./Blender
Executable: ./bin

Ressourcen:
Referenzbilder: https://www.dimensions.com/
Bowlingkugeltextur: https://pixabay.com/de/illustrations/abstrakt-marmor-textur-hintergrund-4557447/
Holztextur: https://muku-store.com/user_data/img/contents/basic_knowledge/about_wood02.jpg
Metalltextur: https://lostandtaken.com/downloads/scratched-scraped-metal-texture-7/
Wand: https://pixabay.com/de/photos/beton-wand-grunge-betonwand-zement-1646788/

Steuerung:
Kameraverfolgung Ein/Aus: C
Position/Winkel/Kraft auswählen: Leertaste